<template>
  <div class="hello">
  </div>
</template>

<script>
export default {
  
}
</script>
<style scoped>
.hello {
  width: 100%;
  height: 736px;
  background: url("../../public/index.jpg") center center no-repeat;
  background-size: cover;
}
</style>
