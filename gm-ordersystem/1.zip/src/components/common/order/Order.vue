<template>
  <div>
    <div class="jiezhang">
      <div class="md">
        <h2>结账</h2>
      </div>
      <div class="zfb">
          <span>
            <img src="../../../assets/ds/zhifu.png" alt="">
            支付方式</span>
          <span class="zfb_2">在线支付</span>
      </div>
    </div>
    <div class="table">
      <div class="table-row">
        <div class="table-cell-1">已选商品</div>
        <div class="table-cell-2">共两份</div>
      </div>
      <hr>
      <div class="table-row">
        <div class="table-cell">长长久久组合</div>
        <div class="table-cell">x1</div>
        <div class="table-cell">¥77</div>
      </div>
    </div>
    <div class="sale">
        <div class="div_0">
          <div class="div_1">
            <span>整单商品优惠</span>
          <span class="sale_1">未使用优惠
            <img src="../../../assets/ds/you.png" alt="">
          </span>
          </div>
          <p>(不可与单商品优惠共享)</p>
        </div>
        <hr>
        <div class="div_2">
          <p>原价</p>
          <span>¥154</span>
          <p>活动优惠</p>
          <span>- ¥20</span>
          <div class="div_3">
            <p>总计<span>¥134</span></p>
          </div>
        </div>
    </div>
    <div id="rem">
      <div>
        <span>备注</span>
        <input type="text" placeholder="请输入备注">
        <hr>
        <span>发票抬头</span>
        <input placeholder="请输入个人或者公司抬头">
        <hr>
        <span>纳税人识别号</span>
        <input placeholder="请输入纳税人识别号">
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return {}
  },
}
</script>
<style>
  #app{
    width:100%;
    justify-content: space-between;
    overflow: hidden;
  }
  .jiezhang{
    border:1px solid #ccc;
    margin:10px 10px;
    padding:15px;
    border-radius: 5px;

  }
  .zfb>span>img{
    width:20px;height:18px;
    vertical-align:text-top;
  }
  .zfb{
    height:15px;
    margin:0 auto;
    color:black;
    font-size: 16px;
  }
  .zfb_2{
    width:100%;
    text-align: right;
    font-size: 16px;
    margin-left:50%;
    color:#ccc;
  }
  
  .sale{
    border:1px solid #ddd;
    margin:10px;
    border-radius: 5px;
  }
  .sale p{
    margin:10px;
  }
  .div_0{
    width:100%;
  }
  .div_1{
    margin-top:10px;
    margin-left:10px;
  }
  .div_1 .sale_1{
    margin-left:150px;
    color:#de1c1c;
    font-size: 15px;
  }
  .sale_1 img{
    width:20px;
    height:17px;
    vertical-align:text-top;
  }
  .div_2{
    width:100%;
  }
  .div_2 p{
    width:10;
    display: inline-block;
  }
  .div_2 span{
    color:red;
    font-size: 16px;
  }
  .div_3{
    text-align: right;
  }
  #rem{
    border-radius: 5px;
    border:1px solid #ddd;
    margin:10px;
    width:95%;
  }
  #rem>div{
    margin:15px;
  }
  input{
    outline:medium;
    border:none;
    text-align: right;
    float: right;
    margin:10px 0 10px;
  }
  #rem span{
    display:inline-block;
    margin:10px 0 10px;
    font-size: 16px;
    color:black;
  }
  .table{
    width:94%;
    display: table;
    table-layout: fixed;
    border:1px solid #ccc;
    margin:10px;
    border-radius: 5px;
  }
  .table-row{
    width:100%;
    display:table-row;
    color:#666;
    font-size: 16px;
  }
  .table-cell{
    width:33%;
    /* display:table-cell; */
    display:inline-block;
    text-align: right;
    margin:10px -10px 10px 0;
  }
  .table-cell-1{
    width:50%;
    display: inline-block;
    text-align:left;
    margin:10px 0 10px 10px;
  }
  .table-cell-2{
    width:50%;
    display: inline-block;
    text-align:right;
    margin:10px 0px 10px -20px;
  }
</style>