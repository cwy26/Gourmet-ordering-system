export default {
    path: '/reservation',
    component: () =>import('@/views/reservation')
}