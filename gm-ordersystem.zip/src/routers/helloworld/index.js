export default {
    path: '/helloworld',
    component: () =>import('@/views/helloworld')
}