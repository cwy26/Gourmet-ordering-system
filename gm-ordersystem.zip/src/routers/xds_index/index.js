export default {
    path: '/index',
    component: () => import('@/views/xds_index.vue')
}